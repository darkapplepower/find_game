from .onclick import Click
class Button(Click):
        def init(self, size, xy, image, callback, pygame):
                