def loop(pygame, screen, size):
        1